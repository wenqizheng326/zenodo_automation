.. _semsql_datamodel:

SemSQL
======

We import the semantic-sql data model for representing ontologies as a relational ORM.

See `<https://w3id.org/semsql/>`_ for more information.
