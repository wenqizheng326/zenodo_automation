

# Slot: deprecated



URI: [owl:deprecated](http://www.w3.org/2002/07/owl#deprecated)



<!-- no inheritance hierarchy -->





## Applicable Classes

| Name | Description | Modifies Slot |
| --- | --- | --- |
| [Meta](Meta.md) | A collection of annotations on an entity or ontology or edge or axiom |  no  |







## Properties

* Range: [Boolean](Boolean.md)





## Identifier and Mapping Information







### Schema Source


* from schema: https://github.com/geneontology/obographs




## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | owl:deprecated |
| native | obographs:deprecated |




## LinkML Source

<details>
```yaml
name: deprecated
from_schema: https://github.com/geneontology/obographs
rank: 1000
slot_uri: owl:deprecated
alias: deprecated
domain_of:
- Meta
range: boolean

```
</details>