# PredsEnum

None

URI: PredsEnum

## Permissible Values

| Value | Meaning | Description | Info |
| --- | --- | --- | --- |
| hasExactSynonym | None | None | |
| hasNarrowSynonym | None | None | |
| hasBroadSynonym | None | None | |
| hasRelatedSynonym | None | None | |


## Identifier and Mapping Information







### Schema Source


* from schema: https://github.com/geneontology/obographs



