# Slot: representitiveNodeId

URI: [https://github.com/geneontology/obographs/representitiveNodeId](https://github.com/geneontology/obographs/representitiveNodeId)



<!-- no inheritance hierarchy -->


## Properties

 * Range: [xsd:string](http://www.w3.org/2001/XMLSchema#string)



## Identifier and Mapping Information







### Schema Source


* from schema: https://github.com/geneontology/obographs



