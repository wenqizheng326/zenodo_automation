# obographs_linkml_model

Schema for benchmarking based on obographs

URI: https://github.com/geneontology/obographs

