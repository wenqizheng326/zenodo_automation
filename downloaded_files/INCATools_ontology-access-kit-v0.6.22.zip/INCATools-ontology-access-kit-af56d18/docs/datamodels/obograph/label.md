# Slot: label

URI: [https://github.com/geneontology/obographs/label](https://github.com/geneontology/obographs/label)



<!-- no inheritance hierarchy -->


## Properties

 * Range: string



## Identifier and Mapping Information





