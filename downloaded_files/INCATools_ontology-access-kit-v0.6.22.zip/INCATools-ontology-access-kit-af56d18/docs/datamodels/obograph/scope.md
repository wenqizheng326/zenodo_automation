# Slot: scope

URI: [https://github.com/geneontology/obographs/scope](https://github.com/geneontology/obographs/scope)



<!-- no inheritance hierarchy -->


## Properties

 * Range: [ScopesEnum](ScopesEnum.md)



## Identifier and Mapping Information







### Schema Source


* from schema: https://github.com/geneontology/obographs



