# ScopesEnum

None

URI: ScopesEnum

## Permissible Values

| Value | Meaning | Description | Info |
| --- | --- | --- | --- |
| exact | None | None | |
| narrow | None | None | |
| broad | None | None | |
| related | None | None | |


## Identifier and Mapping Information







### Schema Source


* from schema: https://github.com/geneontology/obographs



