# lexican-index

A datamodel for representing a lexical index of an ontology

URI: https://w3id.org/linkml/lexical_index

