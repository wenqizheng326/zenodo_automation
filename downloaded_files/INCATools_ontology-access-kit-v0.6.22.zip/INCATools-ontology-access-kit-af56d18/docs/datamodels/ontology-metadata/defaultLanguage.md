

# Slot: defaultLanguage



URI: [protege:defaultLanguage](protege:defaultLanguage)




## Inheritance

* [informative_property](informative_property.md)
    * **defaultLanguage**









## Properties

* Range: [String](String.md)





## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/oak/ontology-metadata




## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | protege:defaultLanguage |
| native | omoschema:defaultLanguage |




## LinkML Source

<details>
```yaml
name: defaultLanguage
from_schema: https://w3id.org/oak/ontology-metadata
rank: 1000
is_a: informative_property
slot_uri: protege:defaultLanguage
alias: defaultLanguage
range: string

```
</details>