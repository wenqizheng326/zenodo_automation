

# Slot: oboInOwl_ontology



URI: [oio:ontology](http://www.geneontology.org/formats/oboInOwl#ontology)



<!-- no inheritance hierarchy -->








## Properties

* Range: [String](String.md)





## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/oak/ontology-metadata




## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | oio:ontology |
| native | omoschema:oboInOwl_ontology |




## LinkML Source

<details>
```yaml
name: oboInOwl_ontology
deprecated: todo
from_schema: https://w3id.org/oak/ontology-metadata
deprecated_element_has_exact_replacement: ontology
rank: 1000
slot_uri: oio:ontology
alias: oboInOwl_ontology
range: string

```
</details>