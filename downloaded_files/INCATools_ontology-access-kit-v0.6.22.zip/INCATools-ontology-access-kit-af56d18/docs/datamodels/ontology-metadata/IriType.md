# Type: IriType




_An IRI_



URI: [xsd:anyURI](http://www.w3.org/2001/XMLSchema#anyURI)

* [base](https://w3id.org/linkml/base): URIorCURIE

* [uri](https://w3id.org/linkml/uri): xsd:anyURI

* [repr](https://w3id.org/linkml/repr): str

* [typeof](https://w3id.org/linkml/typeof): uriorcurie







## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/oak/ontology-metadata




## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | omoschema:iri_type |
| native | omoschema:iri_type |



