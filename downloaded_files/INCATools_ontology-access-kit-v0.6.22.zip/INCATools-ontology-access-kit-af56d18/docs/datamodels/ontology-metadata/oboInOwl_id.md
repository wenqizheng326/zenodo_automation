

# Slot: oboInOwl_id



URI: [oio:id](http://www.geneontology.org/formats/oboInOwl#id)



<!-- no inheritance hierarchy -->








## Properties

* Range: [String](String.md)





## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/oak/ontology-metadata




## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | oio:id |
| native | omoschema:oboInOwl_id |




## LinkML Source

<details>
```yaml
name: oboInOwl_id
from_schema: https://w3id.org/oak/ontology-metadata
rank: 1000
slot_uri: oio:id
alias: oboInOwl_id
range: string

```
</details>