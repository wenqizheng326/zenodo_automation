# omo-schema

Example schema for ontology metadata

URI: http://purl.obolibrary.org/obo/omo/schema

