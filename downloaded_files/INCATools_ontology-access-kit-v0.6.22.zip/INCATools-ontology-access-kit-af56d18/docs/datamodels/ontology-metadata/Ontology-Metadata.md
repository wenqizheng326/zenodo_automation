# Ontology-Metadata

Schema for ontology metadata

URI: https://w3id.org/oak/ontology-metadata

