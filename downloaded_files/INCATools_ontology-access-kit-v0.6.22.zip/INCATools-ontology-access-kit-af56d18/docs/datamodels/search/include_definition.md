# Slot: include_definition

URI: [https://w3id.org/linkml/search_datamodel/include_definition](https://w3id.org/linkml/search_datamodel/include_definition)



<!-- no inheritance hierarchy -->


## Properties

 * Range: [xsd:boolean](http://www.w3.org/2001/XMLSchema#boolean)



## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/linkml/search_datamodel



