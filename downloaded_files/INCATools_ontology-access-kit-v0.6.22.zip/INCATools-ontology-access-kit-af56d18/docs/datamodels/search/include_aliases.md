# Slot: include_aliases

URI: [https://w3id.org/linkml/search_datamodel/include_aliases](https://w3id.org/linkml/search_datamodel/include_aliases)



<!-- no inheritance hierarchy -->


## Properties

 * Range: [xsd:boolean](http://www.w3.org/2001/XMLSchema#boolean)



## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/linkml/search_datamodel



