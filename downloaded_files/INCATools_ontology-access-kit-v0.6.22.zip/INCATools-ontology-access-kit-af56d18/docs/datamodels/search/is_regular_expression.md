# Slot: is_regular_expression

URI: [https://w3id.org/linkml/search_datamodel/is_regular_expression](https://w3id.org/linkml/search_datamodel/is_regular_expression)



<!-- no inheritance hierarchy -->


## Properties

 * Range: [xsd:boolean](http://www.w3.org/2001/XMLSchema#boolean)



## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/linkml/search_datamodel



