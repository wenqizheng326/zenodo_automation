# Slot: include_label

URI: [https://w3id.org/linkml/search_datamodel/include_label](https://w3id.org/linkml/search_datamodel/include_label)



<!-- no inheritance hierarchy -->


## Properties

 * Range: [xsd:boolean](http://www.w3.org/2001/XMLSchema#boolean)



## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/linkml/search_datamodel



