# Slot: left_predicate_name
_The name of the predicate of the source/left edge_


URI: [https://w3id.org/linkml/text_annotator/left_predicate_name](https://w3id.org/linkml/text_annotator/left_predicate_name)



<!-- no inheritance hierarchy -->


## Properties

 * Range: None



## Identifier and Mapping Information





