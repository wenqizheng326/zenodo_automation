# Slot: right_subject_name
_The name of the subject (child) of the matched/right edge, if matchable_


URI: [https://w3id.org/linkml/text_annotator/right_subject_name](https://w3id.org/linkml/text_annotator/right_subject_name)



<!-- no inheritance hierarchy -->


## Properties

 * Range: None



## Identifier and Mapping Information





