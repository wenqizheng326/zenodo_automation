# Slot: right_object_name
_The name of the object (parent) of the matched/right edge, if matchable_


URI: [https://w3id.org/linkml/text_annotator/right_object_name](https://w3id.org/linkml/text_annotator/right_object_name)



<!-- no inheritance hierarchy -->


## Properties

 * Range: None



## Identifier and Mapping Information





