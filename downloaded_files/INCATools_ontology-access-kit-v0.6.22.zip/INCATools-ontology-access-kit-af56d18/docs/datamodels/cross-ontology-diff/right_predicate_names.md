# Slot: right_predicate_names
_The names corresponding to the right_predicate_ids_


URI: [https://w3id.org/linkml/text_annotator/right_predicate_names](https://w3id.org/linkml/text_annotator/right_predicate_names)



<!-- no inheritance hierarchy -->


## Properties

 * Range: None



## Identifier and Mapping Information





