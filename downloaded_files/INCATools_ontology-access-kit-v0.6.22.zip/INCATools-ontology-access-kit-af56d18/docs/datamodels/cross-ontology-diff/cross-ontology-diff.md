# cross-ontology-diff

A datamodel for representing the results of relational diffs across a pair of ontologies connected by mappings

URI: https://w3id.org/oak/cross-ontology-diff

