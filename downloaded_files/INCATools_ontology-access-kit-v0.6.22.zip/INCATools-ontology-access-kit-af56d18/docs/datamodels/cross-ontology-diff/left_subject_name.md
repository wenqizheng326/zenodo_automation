# Slot: left_subject_name
_The name of the subject (child) of the source/left edge_


URI: [https://w3id.org/linkml/text_annotator/left_subject_name](https://w3id.org/linkml/text_annotator/left_subject_name)



<!-- no inheritance hierarchy -->


## Properties

 * Range: None



## Identifier and Mapping Information





