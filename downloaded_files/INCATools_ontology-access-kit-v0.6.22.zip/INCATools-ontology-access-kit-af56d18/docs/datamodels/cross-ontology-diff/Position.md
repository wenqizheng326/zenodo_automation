# Position

None

URI: http://www.w3.org/2001/XMLSchema#integer

* [base](https://w3id.org/linkml/base): int






## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/linkml/cross_ontology_diff



