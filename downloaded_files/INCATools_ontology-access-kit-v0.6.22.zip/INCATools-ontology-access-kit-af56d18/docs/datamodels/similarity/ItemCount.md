# Type: ItemCount



URI: [xsd:integer](http://www.w3.org/2001/XMLSchema#integer)

* [base](https://w3id.org/linkml/base): int

* [uri](https://w3id.org/linkml/uri): xsd:integer


* [typeof](https://w3id.org/linkml/typeof): integer







## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/oak/similarity




## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | sim:ItemCount |
| native | sim:ItemCount |



