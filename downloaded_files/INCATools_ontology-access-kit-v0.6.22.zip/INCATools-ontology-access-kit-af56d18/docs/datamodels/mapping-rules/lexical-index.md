# lexical-index

A datamodel for representing a lexical index of an ontology. A lexical index is keyed by optionally normalized terms.

URI: https://w3id.org/linkml/lexical_index

