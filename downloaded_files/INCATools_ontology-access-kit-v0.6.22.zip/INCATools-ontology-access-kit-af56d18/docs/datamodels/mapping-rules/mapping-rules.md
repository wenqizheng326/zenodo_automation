# mapping-rules

A datamodel for specifying lexical mapping rules. NOTE -- this may move to another package

URI: https://w3id.org/linkml/mapping_rules_datamodel

