.. _kgcl_datamodel:

KGCL
=====

We import the KGCL datamodel for representing ontology changes.

See `KGCL docs <https://github.com/INCATools/kgcl>`_
