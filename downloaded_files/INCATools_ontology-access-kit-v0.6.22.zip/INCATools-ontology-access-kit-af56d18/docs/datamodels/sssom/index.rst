.. _sssom_datamodel:

SSSOM
=====

We import the sssom-py data model for representing ontology mappings.

See `<https://w3id.org/sssom/>`_ for more information.
