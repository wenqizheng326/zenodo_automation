.. _funowl_datamodel:

FunOwl
=======

FunOwl is a :term:`Datamodel` for expressing :term:`OWL`.

FunOwl provides an OWL :term:`Axiom`-oriented datamodel, contrasting from a more :term:`Graph`-oriented data model

See `FunOWL docs <https://github.com/hsolbrig/funowl>`_.
