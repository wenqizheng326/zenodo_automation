# Slot: by_taxon
_statistics keyed by organism taxon_


URI: [https://w3id.org/linkml/reportby_taxon](https://w3id.org/linkml/reportby_taxon)



<!-- no inheritance hierarchy -->


## Properties

 * Range: [FacetStatistics](FacetStatistics.md)



## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/linkml/summary_statistics



