# Type: String




_A character string_



URI: [xsd:string](http://www.w3.org/2001/XMLSchema#string)

* [base](https://w3id.org/linkml/base): str

* [uri](https://w3id.org/linkml/uri): xsd:string









## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/oak/summary_statistics




## Mappings

| Mapping Type | Mapped Value |
| ---  | ---  |
| self | xsd:string |
| native | summary_statistics:string |
| exact | schema:Text |



