# Slot: by_ontology
_statistics keyed by ontology_


URI: [https://w3id.org/linkml/reportby_ontology](https://w3id.org/linkml/reportby_ontology)



<!-- no inheritance hierarchy -->


## Properties

 * Range: [FacetStatistics](FacetStatistics.md)



## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/linkml/summary_statistics



