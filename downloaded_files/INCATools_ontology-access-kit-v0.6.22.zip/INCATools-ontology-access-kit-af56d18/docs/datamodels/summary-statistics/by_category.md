# Slot: by_category
_statistics keyed by category_


URI: [https://w3id.org/linkml/reportby_category](https://w3id.org/linkml/reportby_category)



<!-- no inheritance hierarchy -->


## Properties

 * Range: [FacetStatistics](FacetStatistics.md)



## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/linkml/summary_statistics



