# Slot: by_subset
_statistics keyed by ontology subset_


URI: [https://w3id.org/linkml/reportby_subset](https://w3id.org/linkml/reportby_subset)



<!-- no inheritance hierarchy -->


## Properties

 * Range: [FacetStatistics](FacetStatistics.md)



## Identifier and Mapping Information







### Schema Source


* from schema: https://w3id.org/linkml/summary_statistics



